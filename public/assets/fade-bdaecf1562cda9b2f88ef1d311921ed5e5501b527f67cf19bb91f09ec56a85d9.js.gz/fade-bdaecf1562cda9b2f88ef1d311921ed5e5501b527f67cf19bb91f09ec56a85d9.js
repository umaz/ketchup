<script type="text/javascript">
function execute() {
  document.getElementById("word").className = "fadeout";
}
setTimeout(execute,8500);
setTimeout("location.reload()",10000);
</script>
